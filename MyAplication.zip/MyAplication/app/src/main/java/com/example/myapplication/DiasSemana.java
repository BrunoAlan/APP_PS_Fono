package com.example.myapplication;

import android.support.design.button.MaterialButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class DiasSemana extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dias_semana);
        setTitle("Días de la Semana");
        setup();

    }

    void setup() {
        MaterialButton btn1 = findViewById(R.id.opcion1);
        MaterialButton btn2 = findViewById(R.id.opcion2);
        MaterialButton btn3 = findViewById(R.id.opcion3);

        setTexts(btn1,btn2,btn3);

    }

    void setTexts(MaterialButton btn1,MaterialButton btn2, MaterialButton btn3) {
        ArrayList<String> dias = new ArrayList<String>();
        dias.add("Lunes");
        dias.add("Martes");
        dias.add("Miércoles");
        dias.add("Jueves");
        dias.add("Viernes");
        dias.add("Sábado");
        dias.add("Domingo");

        int randomNum1 = ThreadLocalRandom.current().nextInt(0, 6 + 1);
        btn1.setText(dias.get(randomNum1));
        int randomNum2 = ThreadLocalRandom.current().nextInt(0, 6 + 1);
        btn2.setText(dias.get(randomNum2));
        int randomNum3 = ThreadLocalRandom.current().nextInt(0, 6 + 1);
        btn3.setText(dias.get(randomNum3));

    }

}
